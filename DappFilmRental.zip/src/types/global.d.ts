interface Window {
  ethereum?: any;
}

declare module 'ethers' {
  export * from 'ethers/lib/ethers';
}
