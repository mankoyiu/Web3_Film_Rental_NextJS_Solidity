// DEPRECATED: Use Web3Context instead.

export function WalletProvider() {
  throw new Error('WalletProvider is deprecated. Use Web3Provider instead.')
}

export function useWallet() {
  throw new Error('useWallet is deprecated. Use useWeb3 instead.')
}
